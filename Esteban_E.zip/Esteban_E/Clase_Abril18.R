library(readxl)

Base1<-read.table("Salaries.txt",header=TRUE,sep="\t",dec=".")

View(Base1)

Base2<-read.table("Salaries.csv",header=TRUE,sep=",",dec=".")

View(Base2)

Base3<- read_xls("Salaries.xlsx")

View(Base3)

library(readr)
Salaries <- read_csv("Salaries.csv")
View(Salaries)

x<- c(15,20,18,16,21,16)

mean (x)

median (x)

library(modeest)
mlv(x,method="mfv")[1]

var(x)
sd(x)

quantile(x,0.25)
quantile(x,0.50)
quantile(x,0.75)

sd(x)/mean(x)*100

x<-Base1$salary

mean(x)
median(x)
library(modeest)
mlv(x,method = "mfv")[1]
var(x)
sd(x)
cv<-sd(x)/mean(x)*100
quantile(x,0.25)
quantile(x,0.50)
quantile(x,0.75)



#para datos na

x<- c(15,20,18,16,21,16,NA)

mean(x,na.rm = TRUE)

library(tidyverse)

library(readxl)
Salaries <- read_excel("~/Esteban_E/Salaries (2).xlsx")
View(Salaries)

BaseSal_1<-select(Salaries,rank,sex,salary)
view(BaseSal_1)

BaseSal_2<-filter(Salaries,sex=="Male")
View(BaseSal_2)

BaseSal_3<- Salaries %>%
  select(rank,sex,salary) %>% 
  filter(sex=="Male")
view 

BaseSal_4 <-Salaries %>% 
  select(rank,sex,salary,yrs.service) %>% 
  filter(yrs.service>=10) %>%
  mutate(Salcop= salary *4556.04) %>% 
  group_by(rank,sex) %>% 
  summarize(promUSD=mean(salary),promCop=mean(Salcop),
  medUSD=med(salary),
  medCOP=med(Salcop))
view (BaseSal_4)


  
